package ar.org.centro8.curso.docentes.java.test;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Stack;
import java.util.TreeSet;
import java.util.Vector;

import ar.org.centro8.curso.docentes.java.entities.Persona;

public class TestCollection {
    public static void main(String[] args) {
        System.out.println("-- Collections --");

        //Interface List
        // <Generic>
        List<Persona> lista=null;
        lista=new ArrayList();
        //lista=new LinkedList();
        //lista=new Vector();

        lista.add(new Persona("Ana", "Gallo", 30));     //0
        lista.add(new Persona("Juan", "Sosa", 40));     //2
        lista.add(new Persona("Maria", "Mendez", 40));   //3
        lista.add(new Persona("Maria", "Mendez", 40));  //4

        //lista.remove(1);
        lista.add(1,new Persona("Raul", "Perez", 60));  //1 
        lista.add(new Persona("Victor", "Perez", 40));
        lista.add(new Persona("Beatriz", "Perez", 40));
        lista.add(new Persona("Ana", "Perez", 40));
        lista.add(new Persona("Beatriz", "Perez", 30));

        //System.out.println(lista.get(2));

        //Recorrido por indices
        //for(int a=0; a<lista.size(); a++){
        //    System.out.println(lista.get(a));
        //}

        //Recorrido foreach
        //for(Persona p:lista) System.out.println(p);

        //Recorrido con método forEach Java 8 o sup
        //lista.forEach(p->System.out.println(p));
        //lista.forEach(p->{
        //    System.out.println("*");
        //    System.out.println(p);
        //});
        lista.forEach(System.out::println);

        //Interface Set
        Set<String>setSemana=null;

        //Implementación HashSet:   es la más veloz, no garantiza el orden.
        //setSemana=new HashSet();

        //Implementación LinkedHashSet almacena por orden de ingreso
        //setSemana=new LinkedHashSet();

        //Implementación TreeSet: almacena por orden natural (alfabeticamente)
        setSemana=new TreeSet();

        setSemana.add("Lunes");
        setSemana.add("Martes");
        setSemana.add("Miércoles");
        setSemana.add("Jueves");
        setSemana.add("Viernes");
        setSemana.add("Sábado");
        setSemana.add("Domingo");
        setSemana.add("Lunes");

        setSemana.forEach(System.out::println);

        Set<Persona>setPersonas=null;

        //setPersonas=new LinkedHashSet();
        //setPersonas=new HashSet();
        setPersonas=new TreeSet();

        //lista.forEach(setPersonas::add);
        setPersonas.addAll(lista);

        //setPersonas.forEach(System.out::println);
        setPersonas.forEach(p->System.out.println(p+" : "+p.hashCode()));

        //Pilas en Java
        Stack<Persona>pilaPersona=new Stack();
        pilaPersona.push(new Persona("Matias", "Moretti", 20));
        //método .push() apila un elemento.
        pilaPersona.addAll(lista);

        System.out.println("Longitud de pila: "+pilaPersona.size());
        while(!pilaPersona.isEmpty()){
            System.out.println(pilaPersona.pop());
            //método .pop() desapila un elemento
        }
        System.out.println("Longitud de pila: "+pilaPersona.size());

        //Colas en Java
        ArrayDeque<Persona> colaPersona=new ArrayDeque();
        colaPersona.offer(new Persona("Matias", "Moretti", 20));
        //Método .offer() encola un elemento

        colaPersona.addAll(lista);

        System.out.println("Longitud de cola: "+colaPersona.size());
        while(!colaPersona.isEmpty()){
            System.out.println(colaPersona.poll());
            //Método .poll() desencola un elemento
        }
        System.out.println("Longitud de cola: "+colaPersona.size());

        //TODO Interface Map

    }
}
