package ar.org.centro8.curso.docentes.java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase01Application {

	public static void main(String[] args) {
		SpringApplication.run(Clase01Application.class, args);
	}

}
