package ar.org.centro8.curso.docentes.java.test;

import ar.org.centro8.curso.docentes.java.entities.Persona;
import ar.org.centro8.curso.docentes.java.entities.Persona2;

public class TestPersona {
    public static void main(String[] args) {
        System.out.println("-- Test Persona --");
        Persona persona1=new Persona("Juan", "Perez", 40);
        persona1.setEdad(41);
        System.out.println(persona1);

        System.out.println("-- Test Persona2 --");
        Persona2 persona2=new Persona2("Lorena", "Gomez", 34);
        persona2.setEdad(35);
        System.out.println(persona2);

    }
}
