package ar.org.centro8.curso.docentes.java.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
//@NoArgsConstructor
//@Getter
//@Setter
//@ToString
@Data
public class Persona2 {
    private String nombre;
    private String apellido;
    private int edad;
}
