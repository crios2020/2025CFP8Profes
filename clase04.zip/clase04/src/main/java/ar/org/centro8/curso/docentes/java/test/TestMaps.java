package ar.org.centro8.curso.docentes.java.test;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import ar.org.centro8.curso.docentes.java.enums.EstadoCivil;
import ar.org.centro8.curso.docentes.java.enums.Genero;

public class TestMaps {
    public static void main(String[] args) {
        Map<String,String>mapaSemana=null;
        
        //mapaSemana=new HashMap();       //rápido pero desordenado
        //mapaSemana=new Hashtable();         //rápido y desordenado pero obsoleto NO RECOMENDADO 
        //mapaSemana=new LinkedHashMap();     //almacena en una lista enlazada por orden de ingreso según clave
        mapaSemana=new TreeMap();           //almacena en un arbol por orden natural de clave

        // app
        mapaSemana.put("lu", "LUNES");
        mapaSemana.put("ma", "Martes");
        mapaSemana.put("mi", "Miércoles");
        mapaSemana.put("ju", "Jueves");
        mapaSemana.put("vi", "Viernes");
        mapaSemana.put("sa", "Sábado");
        mapaSemana.put("do", "Domingo");
        mapaSemana.put("lu", "Lunes");
        System.out.println(mapaSemana.get("ma"));

        //Recorrido
        mapaSemana.forEach((k,v)->System.out.println(k+" - "+v));

        //Mapa System.properties
        System.out.println(System.getProperties());
        System.out.println("***************************************");
        System.getProperties().forEach((k,v)->System.out.println(k+": "+v));
        System.out.println("***************************************");
        System.out.println(System.getProperty("os.name"));
        System.out.println(System.getProperty("os.version"));
        System.out.println(System.getProperty("os.arch"));
        System.out.println(System.getProperty("user.name"));
        System.out.println(System.getProperty("user.country"));
        System.out.println(System.getProperty("user.language"));
        System.out.println(System.getProperty("user.dir"));
        System.out.println(System.getProperty("java.version"));
        System.out.println(System.getProperty("java.vm.name"));
        System.out.println(System.getProperty("java.vendor"));


        //Mapa de entorno   env
        System.out.println(System.getenv());
        System.out.println("***************************************");
        System.getenv().forEach((k,v)->System.out.println(k+": "+v));
        System.out.println("***************************************");
        System.out.println(System.getenv().get("USER"));
        System.out.println(System.getenv("USER"));

        //ENUMERADOS EN JAVA

        EstadoCivil estadoCivil=EstadoCivil.SOLTERO;
        Genero genero=Genero.FEMENINO;

        List
                .of(EstadoCivil.values())
                .forEach(System.out::println);
        


    }   
}
