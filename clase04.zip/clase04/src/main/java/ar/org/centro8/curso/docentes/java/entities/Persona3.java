package ar.org.centro8.curso.docentes.java.entities;

import ar.org.centro8.curso.docentes.java.enums.EstadoCivil;
import ar.org.centro8.curso.docentes.java.enums.Genero;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Persona3 {
    private String nombre;
    private String apellido;
    private int edad;
    private EstadoCivil estadoCivil;
    private Genero genero;
}
