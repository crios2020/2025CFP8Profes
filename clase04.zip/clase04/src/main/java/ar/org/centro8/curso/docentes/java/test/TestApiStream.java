package ar.org.centro8.curso.docentes.java.test;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

import ar.org.centro8.curso.docentes.java.entities.Persona;

public class TestApiStream {
        public static void main(String[] args) throws Exception {
                List<Persona> lista = null;
                lista = new ArrayList();

                lista.add(new Persona("Ana", "Gallo", 30));
                lista.add(new Persona("Juan", "Sosa", 40));
                lista.add(new Persona("Maria", "Mendez", 40));
                lista.add(new Persona("Maria", "Mendez", 40));
                lista.add(new Persona("Raul", "Perez", 60));
                lista.add(new Persona("Victor", "Perez", 40));
                lista.add(new Persona("Beatriz", "Perez", 40));
                lista.add(new Persona("Ana", "Perez", 40));
                lista.add(new Persona("Beatriz", "Perez", 30));
                lista.add(new Persona("Juan", "Perez", 25));

                ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("personas.dat"));
                for (Persona p : lista)
                        out.writeObject(p);
                out.close();

                // select * from lista;
                System.out.println("****************************");
                lista.stream().forEach(System.out::println);

                // select * from lista where edad>=45;
                System.out.println("****************************");
                // for(Persona p:lista){
                // if(p.getEdad()>=45) System.out.println(p);
                // }

                // lista.forEach(p->{
                // if(p.getEdad()>=45) System.out.println(p);
                // });

                lista
                                .stream()
                                .filter(p -> p.getEdad() >= 45)
                                .forEach(System.out::println);

                // select * from lista where nombre="ana";
                System.out.println("****************************");

                /*
                 * System.out.println(lista.get(0).getNombre());
                 * System.out.println(lista.get(0).getNombre()=="Ana");
                 * System.out.println("ingrese su nombre: ");
                 * String nombre=new Scanner(System.in).nextLine();
                 * System.out.println(nombre=="Ana");
                 * System.out.println(nombre.equals("Ana"));
                 */

                lista
                                .stream()
                                .filter(p -> p.getNombre().equalsIgnoreCase("ana"))
                                .forEach(System.out::println);

                // select * from lista where nombre="ana" and apellido="perez";
                System.out.println("****************************");

                // lista
                // .stream()
                // .filter(p->p.getNombre().equalsIgnoreCase("ana")
                // && p.getApellido().equalsIgnoreCase("perez"))
                // .forEach(System.out::println);

                List<Persona> personas = new ArrayList();
                ObjectInputStream in = new ObjectInputStream(new FileInputStream("personas.dat"));
                try {
                        while (true) {
                                personas.add((Persona) in.readObject());
                        }
                } catch (EOFException e) {

                }

                personas
                                // lista
                                .stream()
                                .filter(p -> p.getNombre().equalsIgnoreCase("ana"))
                                .filter(p -> p.getApellido().equalsIgnoreCase("perez"))
                                .forEach(System.out::println);

                // select * from colores where color="rojo";
                System.out.println("****************************");
                new BufferedReader(new FileReader("colores.txt"))
                                .lines()
                                .filter(c -> c.equalsIgnoreCase("rojo"))
                                .forEach(System.out::println);

                // select * from colores where color like "r%";
                System.out.println("****************************");
                new BufferedReader(new FileReader("colores.txt"))
                                .lines()
                                .filter(c -> c.toLowerCase().startsWith("r"))
                                .forEach(System.out::println);

                // select * from colores where color like "%rojo%";
                System.out.println("****************************");
                new BufferedReader(new FileReader("colores.txt"))
                                .lines()
                                .filter(c -> c.toLowerCase().contains("rojo"))
                                .forEach(System.out::println);
/*
                new BufferedReader(
                                new InputStreamReader(
                                                new URL("https://listado.mercadolibre.com.ar/plancha#D[A:plancha]")
                                                                .openStream()))
                                .lines()
                                .forEach(System.out::println);
*/
                // select * from lista where nombre="ana" or apellido="perez";
                System.out.println("****************************");

                lista
                                .stream()
                                .filter(p -> p.getNombre().equalsIgnoreCase("ana")
                                                || p.getApellido().equalsIgnoreCase("perez"))
                                .forEach(System.out::println);

                // select * from lista where edad between 30 and 40;
                System.out.println("****************************");
                lista
                        .stream()
                        .filter(p->p.getEdad()>=30)
                        .filter(p->p.getEdad()<=40)
                        .forEach(System.out::println);

                // select * from lista where edad not between 30 and 40;
                System.out.println("****************************");
                lista
                        .stream()
                        .filter(p->p.getEdad()<30 || p.getEdad()>40)
                        .forEach(System.out::println);
                
                // select * from lista where nombre like 'l%'
                System.out.println("****************************");
                lista
                        .stream()
                        .filter(p -> p.getNombre().toLowerCase().startsWith("l"))
                        .forEach(System.out::println);

                // select * from lista where nombre like '%a'
                System.out.println("****************************");
                lista
                        .stream()
                        .filter(p -> p.getNombre().toLowerCase().endsWith("a"))
                        .forEach(System.out::println);

                // select * from lista where nombre like '%ar%'
                System.out.println("****************************");
                lista
                        .stream()
                        .filter(p -> p.getNombre().toLowerCase().contains("ar"))
                        .forEach(System.out::println);


                // select * from lista order by apellido'
                System.out.println("****************************");

                //orden natural (compareTo)
                // lista
                //         .stream()
                //         .sorted()
                //         .forEach(System.out::println);
                
                // new BufferedReader(new FileReader("colores.txt"))
                //         .lines()
                //         .sorted()
                //         .forEach(System.out::println);

                lista
                        .stream()
                        .sorted(Comparator.comparing(Persona::getApellido))
                        .forEach(System.out::println);

                // select * from lista where edad>=30 order by apellido desc'
                System.out.println("****************************");
                lista
                        .stream()
                        .filter(p->p.getEdad()>=30)
                        .sorted(Comparator.comparing(Persona::getApellido).reversed())
                        .forEach(System.out::println);
                
                // select * from lista where edad>=30 order by apellido, nombre '
                System.out.println("****************************");
                lista
                        .stream()
                        .filter(p->p.getEdad()>=30)
                        //.sorted(Comparator.comparing(Persona::getNombre))
                        //.sorted(Comparator.comparing(Persona::getApellido))
                        .sorted(Comparator.comparing(Persona::getApellido).thenComparing(Persona::getNombre))
                        .forEach(System.out::println);

                // select max(edad) from personas
                System.out.println("****************************");
                int edadMaxima=lista
                                        .stream()
                                        .max(Comparator.comparingInt(Persona::getEdad))
                                        .get()
                                        .getEdad();
                
                System.out.println("Edad Máxima: "+edadMaxima);

                // select * from personas where edad= (select max(edad) from personas);
                System.out.println("****************************");
                lista
                        .stream()
                        .filter(p->p.getEdad()==(edadMaxima))
                        .forEach(System.out::println);

        }
}
