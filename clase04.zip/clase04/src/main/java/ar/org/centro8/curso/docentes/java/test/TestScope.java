package ar.org.centro8.curso.docentes.java.test;

import ar.org.centro8.curso.docentes.java.entities.Persona;

public class TestScope {

    private static int atributo=10; //variable global

    private static Persona persona;
    private static String saludo;
    private static int num;

    public static void main(String[] args) {
        //Scope - Alcance

        int var=2;

        System.out.println(var);

        {
            //ambito de software
            System.out.println(var);
            int var2=8;
            System.out.println(var2);
        }

        //System.out.println(var2);

        System.out.println(atributo);

        //Las variables deben inicializarce
        //los atributos se inicializan automaticamente
        //los atriburos numericos se inician en 0
        //los atributos string o referenciados se inician en null

        Persona p;
        String texto;
        int numero;
        //System.out.println(p);
        //System.out.println(texto);
        //System.out.println(numero);

        System.out.println(persona);
        System.out.println(saludo);
        System.out.println(num);


    }

    public static void main2(){
        //System.out.println(var);
        //System.out.println(var2);

        System.out.println(atributo);
    }
}
