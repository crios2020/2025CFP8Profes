package ar.org.centro8.curso.docentes.java.enums;

public enum EstadoCivil {
    SOLTERO,
    CASADO,
    VIUDO,
    DIVORCIADO
}
