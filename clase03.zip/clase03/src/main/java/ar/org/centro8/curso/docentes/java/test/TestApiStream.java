package ar.org.centro8.curso.docentes.java.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import ar.org.centro8.curso.docentes.java.entities.Persona;

public class TestApiStream {
    public static void main(String[] args) {
        List<Persona> lista=null;
        lista=new ArrayList();

        lista.add(new Persona("Ana", "Gallo", 30));     
        lista.add(new Persona("Juan", "Sosa", 40));     
        lista.add(new Persona("Maria", "Mendez", 40));  
        lista.add(new Persona("Maria", "Mendez", 40));  
        lista.add(new Persona("Raul", "Perez", 60));   
        lista.add(new Persona("Victor", "Perez", 40));
        lista.add(new Persona("Beatriz", "Perez", 40));
        lista.add(new Persona("Ana", "Perez", 40));
        lista.add(new Persona("Beatriz", "Perez", 30));


        // select * from lista;
        System.out.println("****************************");
        lista.stream().forEach(System.out::println);

        // select * from lista where edad>=45;
        System.out.println("****************************");
        //for(Persona p:lista){
        //    if(p.getEdad()>=45) System.out.println(p);
        //}

        //lista.forEach(p->{
        //    if(p.getEdad()>=45) System.out.println(p);
        //});

        lista
                .stream()
                .filter(p->p.getEdad()>=45)
                .forEach(System.out::println);

        // select * from lista where nombre="ana";
        System.out.println("****************************");
        
        /*
        System.out.println(lista.get(0).getNombre());
        System.out.println(lista.get(0).getNombre()=="Ana");
        System.out.println("ingrese su nombre: ");
        String nombre=new Scanner(System.in).nextLine();
        System.out.println(nombre=="Ana");
        System.out.println(nombre.equals("Ana"));
        */

        lista
                .stream()
                .filter(p->p.getNombre().equalsIgnoreCase("ana"))
                .forEach(System.out::println);
        

        // select * from lista where nombre="ana" and apellido="perez";
        System.out.println("****************************");

        // lista
        //     .stream()
        //     .filter(p->p.getNombre().equalsIgnoreCase("ana") 
        //             && p.getApellido().equalsIgnoreCase("perez"))
        //     .forEach(System.out::println);
        
        lista
                .stream()
                .filter(p->p.getNombre().equalsIgnoreCase("ana"))
                .filter(p->p.getApellido().equalsIgnoreCase("perez")) 
                .forEach(System.out::println);

                
    }   
}
