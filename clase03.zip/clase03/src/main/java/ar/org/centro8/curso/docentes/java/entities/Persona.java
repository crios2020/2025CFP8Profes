package ar.org.centro8.curso.docentes.java.entities;

import java.text.DecimalFormat;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Persona implements Comparable<Persona>{
    private String nombre;
    private String apellido;
    private int edad;

    @Override
    public int compareTo(Persona para) {
        DecimalFormat df=new DecimalFormat("000");
        String thisPersona=this.getApellido()+","+this.getNombre()+","+df.format(this.getEdad());
        String paraPersona=para.getApellido()+","+para.getNombre()+","+df.format(para.getEdad());
        return thisPersona.compareTo(paraPersona); //*-1;
    }



    /**
     * Constructor de clase persona
     * @param nombre    Nombre de la persona
     * @param apellido  Apellido de la persona
     * @param edad      Edad de la persona
     */
    /*
     public Persona(String nombre, String apellido, int edad) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "Persona [nombre=" + nombre + ", apellido=" + apellido + ", edad=" + edad + "]";
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public int hashCode() {
        return this.toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if(obj==null) return false;
        return this.hashCode()==obj.hashCode();
    } 

    */

}
