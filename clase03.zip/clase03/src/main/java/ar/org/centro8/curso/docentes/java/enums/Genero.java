package ar.org.centro8.curso.docentes.java.enums;

public enum Genero {
    FEMENINO,
    MASCULINO,
    X
}
